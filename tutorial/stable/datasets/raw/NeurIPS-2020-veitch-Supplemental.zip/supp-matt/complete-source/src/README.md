Complete code and data for "Sense and Sensitivity Analysis".

Included for completeness---we recommend you instead start with the simpler and clear demo repo.
